/**
 * Dasboard Routes
 */
import React, { Component } from 'react';
import { Redirect, Route, Switch } from 'react-router-dom';
import axios from 'axios';

import MUIDataTable from "mui-datatables";

// page title bar
import PageTitleBar from 'Components/PageTitleBar/PageTitleBar';

// rct card box
import { RctCard, RctCardContent } from 'Components/RctCard'; 

// intl messages
import IntlMessages from 'Util/IntlMessages';

// import Base URL from Config
import {baseURL} from '../../../services/Config';

// MUI Theme - added to customize cell Theme  
import { createMuiTheme, MuiThemeProvider } from '@material-ui/core/styles';

//Bootstrap datatable custom cell style
import BootstrapTable from 'react-bootstrap-table-next';
import paginationFactory from 'react-bootstrap-table2-paginator';
import cellEditFactory from 'react-bootstrap-table2-editor';

export default class chuteStatus extends Component {

    state = {  
        data: [],
        columns: {},
        colData: []
     };

    linkState = this.props.location.state === undefined ? '' : this.props.location.state.nextLink; 

    /*calling rest for the first time after mount
	 *it will call render twice but update only once
	 *Used to remove unsafe life cycle methods.*/
	componentDidMount() {
		this.onReload();
    }
    

    // on reload fetch new data from data base
	onReload = () => {
		let tableData = [];
        axios.get(baseURL+'chutedetails/'+ localStorage.getItem("user_id") )
            .then(res => {
                //Data Extraxtion fro Reactify MUI DataTable
                for (let i = 0; i < res.data.length; i++) {
                    const row = res.data[i];
					console.log("------- chute status data -----------");
					console.log(res.data[i])
                    const tableColumns = ["Chute No.", "Full", "Disabled", "Duration", "Timestamp"];
                    tableData.push(
                        [{
							chute_nbr:row.chute_nbr,
                            product_full:row.product_full,
                            product_disabled:row.product_disabled,
                            duration:row.duration,
                            timestamp:row.created_ts
                        }]
                    );
                    //Set Extracted Data in State
                    this.setState({ 
                        tableData: tableData,
                        tableColumns: tableColumns
                    });
                  }
                 
            }).catch(function (error) {
                console.log(error);
        });
    }


    /*getMuiTheme = () => createMuiTheme({
        overrides: {
                      MUIDataTableHeadCell : {
                                      root: {                                   
                                          padding: '4px 20px 4px 20px',     
                                          fontSize: '13px',
                                          color: 'black'                                         
                        }}, 
         
                      MUIDataTableBodyCell: {
                        root: {                                 
                                        padding: '4px 20px 4px 20px',
                                        fontSize: '12px'
                        }
                      },
                      MUIDataTableToolbar: {
                             root: {
                                display: 'none'
                            }
                        } 
        }
      }) */
	  
	  // ["Chute No.", "Full", "Disabled", "Duration", "Timestamp"]
	  
	  

		/*const products = [
			{"id":2,"station":"Station A","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":10,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"user1"},
			{"id":3,"station":"Station B","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":60,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"pqr","last_scan":"2018-01-01 12:00:17","userid":"user2"},
			{"id":4,"station":"Station C","runtime":"02:57","total_inducts":2000,"inducts_per_hour":1000,"utilization":79,"peak_rate":2000,"avg_rate":2500,"min_rate":3000,"current_usr":"xyz","last_scan":"2018-01-01 12:00:17","userid":"Ramesh"}
		]; */
	  
	  

    render() {
        //Fetch Sorter ID from URL params
        const { sorterID } = this.props.match.params;	
        
        {/*const options = {
            filterType: 'dropdown',
            responsive: 'stacked',
            selectableRows: false // to remove the checkbox
        }; */}
		
		//Bootstrap datatable custom cell style
		const headerSortingStyle = { backgroundColor: '#c8e6c9' };
		
		console.log("state tableData");
		console.log(this.state.tableData);
		var test = this.state.tableData;
		
				console.log(" before test");

		/*test = test.map((row, index) => {
			{
				chute_nbr:row.chute_nbr;
				product_full:row.product_full;
				product_disabled:row.product_disabled;
				duration:row.duration;
				timestamp:row.created_ts;
			}
		});*/
		
		console.log(" after test");
		console.log(test);
		
		const columns = [			
			{
				dataField: 'chute_nbr',
				text: 'Chute No.',
				sort: true,
				headerSortingStyle
			},
			{
				dataField: 'product_full',
				text: 'Full',
				sort: true,
				headerSortingStyle
			},
			{
				dataField: 'product_disabled',
				text: 'Disabled',
				sort: true,
				headerSortingStyle
			},
			{
				dataField: 'duration',
				text: 'Duration',
				sort: true,
				headerSortingStyle				
			},
			{
				dataField: 'timestamp',
				text: 'Timestamp',
				sort: true,
				headerSortingStyle
			}
		];
		
		const products = [
			{chute_nbr: 235, product_full: "Y", product_disabled: "N", duration: "00:08",timestamp : "2018-01-01 12:00:17"},
			{chute_nbr: 245, product_full: "N", product_disabled: "Y", duration: "00:18",timestamp : "2018-01-02 12:00:17"},
			{chute_nbr: 255, product_full: "Y", product_disabled: "N", duration: "00:28",timestamp : "2018-01-03 12:00:17"},
			{chute_nbr: 265, product_full: "N", product_disabled: "Y", duration: "00:38",timestamp : "2018-01-04 12:00:17"}
		];
		console.log("products-----");
		console.log(products);

        return (
            <div className="data-table-wrapper">
                <PageTitleBar 
                    title={<IntlMessages id="sidebar.chuteStatusTable" />} 
					match={this.props.match} 
                    url={`/app/dashboard/sorterDetails/${sorterID}`}
                />
                {/* Card To hold Table */}
                <RctCard>
		            <RctCardContent>
                       {/* <div className="contextual-link float-left chute-sub-header">
                            Chute Status
                        </div> */}
                        <div className="contextual-link float-right">
                            <i className=" refresh-button" onClick={() => this.onReload()}><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24"><path d="M12 6v3l4-4-4-4v3c-4.42 0-8 3.58-8 8 0 1.57.46 3.03 1.24 4.26L6.7 14.8c-.45-.83-.7-1.79-.7-2.8 0-3.31 2.69-6 6-6zm6.76 1.74L17.3 9.2c.44.84.7 1.79.7 2.8 0 3.31-2.69 6-6 6v-3l-4 4 4 4v-3c4.42 0 8-3.58 8-8 0-1.57-.46-3.03-1.24-4.26z"/></svg></i>
                        </div> 
						{/* Reactify Chute Status Data Table Start */}
                        {/*<MuiThemeProvider theme={this.getMuiTheme()}>
                        <MUIDataTable
                            // title={"Chute Status Table"}
                            data={this.state.tableData}
                            columns={this.state.tableColumns}
                            options={options}
                        />
                        </MuiThemeProvider> */}
						{/* Reactify Chute Status Data Table End */}
						<BootstrapTable 
						keyField='id' 
						data={ products } 
						columns={ columns }
						striped
						hover
						condensed 
						pagination={ paginationFactory() }
						cellEdit={ cellEditFactory({ mode: 'click' }) }
					/> 
                    </RctCardContent>
			    </RctCard >
            </div>
        );
    }
}


