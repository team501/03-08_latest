import React, {Component} from 'react';
import Grid from '@material-ui/core/Grid';

//json
import json from '../../assets/data/jsonDataConfig/Sorter/watchesJson';

//watch images
import Runtime from '../../assets/img/runtime_icon.png';
import Total from '../../assets/img/Total_icon.png';
import Stops from '../../assets/img/Total_icon-03.png';

//rct collapsible card
import RctCollapsibleCard from 'Components/RctCollapsibleCard/RctCollapsibleCard';

const imageRuntime = {
		width: '65px',
		marginTop: '5%'
}

const textStyle = {
	fontSize: '24px',
	padding: '5px'
}

const hrsStyle = {
	fontSize: '35px', 
	color: '#008bff'
}

class index extends Component { 
	render() { 
		return (
				<div colClasses="col-sm-12 col-md-12 col-lg-12 w-xs-full">
				<RctCollapsibleCard
				colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align wave-status-area-height"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Runtime} />
					</div>
					<div className="text-center" style={textStyle}>
						{json.watches.runtime.title}
					</div>
					<div className="text-center" style={hrsStyle}>
						{json.watches.runtime.time}
					</div>
				</RctCollapsibleCard>
				<RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align wave-status-area-height"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Total} />
					</div>
					<div className="text-center" style={textStyle}>
						{json.watches.total.title}
					</div>
					<div className="text-center" style={hrsStyle}>
						{json.watches.total.time}
					</div>
				</RctCollapsibleCard>
				<RctCollapsibleCard
					colClasses="col-md-4 col-xl-4 col-sm-4 col-ls-4 left-align wave-status-area-height"
				>
					<div className="text-center">
						<img style={imageRuntime} src={Stops} />
					</div>
					<div className="text-center" style={textStyle}>
						{json.watches.stops.title}
					</div>
					<div className="text-center" style={hrsStyle}>
						{json.watches.stops.time}
					</div>
				</RctCollapsibleCard>
				<div class="clearboth"></div>
			</div>
			
				 
		);}
}
export default index;